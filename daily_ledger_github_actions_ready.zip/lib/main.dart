import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DailyLedgerApp());
}

class DailyLedgerApp extends StatelessWidget {
  const DailyLedgerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'দৈনিক হিসাব খাতা',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
      ),
      home: const LedgerHomeScreen(),
    );
  }
}

class LedgerEntry {
  final String id;
  final DateTime date;
  final double credit;
  final double debit;

  LedgerEntry({
    required this.id,
    required this.date,
    required this.credit,
    required this.debit,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'credit': credit,
        'debit': debit,
      };

  factory LedgerEntry.fromJson(Map<String, dynamic> json) {
    return LedgerEntry(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      credit: (json['credit'] as num).toDouble(),
      debit: (json['debit'] as num).toDouble(),
    );
  }
}

class LedgerHomeScreen extends StatefulWidget {
  const LedgerHomeScreen({super.key});

  @override
  State<LedgerHomeScreen> createState() => _LedgerHomeScreenState();
}

class _LedgerHomeScreenState extends State<LedgerHomeScreen> {
  static const String _storageKey = 'daily_ledger_entries_v1';

  final List<LedgerEntry> _entries = [];
  final DateFormat _dateFormat = DateFormat('dd-MM-yyyy');

  DateTime? _startDate;
  DateTime? _endDate;
  bool _isFilterActive = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_storageKey);

    if (saved != null && saved.isNotEmpty) {
      try {
        final List<dynamic> decoded = jsonDecode(saved);
        _entries
          ..clear()
          ..addAll(
            decoded.map(
              (item) => LedgerEntry.fromJson(
                Map<String, dynamic>.from(item as Map),
              ),
            ),
          );
      } catch (_) {
        // If old/corrupt saved data exists, start with an empty ledger.
        _entries.clear();
      }
    }

    if (!mounted) return;
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(
      _entries.map((entry) => entry.toJson()).toList(),
    );
    await prefs.setString(_storageKey, encoded);
  }

  List<LedgerEntry> get _filteredEntries {
    if (!_isFilterActive || _startDate == null || _endDate == null) {
      return _entries;
    }

    return _entries.where((entry) {
      final entryDate =
          DateTime(entry.date.year, entry.date.month, entry.date.day);
      final start =
          DateTime(_startDate!.year, _startDate!.month, _startDate!.day);
      final end =
          DateTime(_endDate!.year, _endDate!.month, _endDate!.day);

      return (entryDate.isAtSameMomentAs(start) || entryDate.isAfter(start)) &&
          (entryDate.isAtSameMomentAs(end) || entryDate.isBefore(end));
    }).toList();
  }

  double get _totalCredit =>
      _filteredEntries.fold(0.0, (sum, item) => sum + item.credit);

  double get _totalDebit =>
      _filteredEntries.fold(0.0, (sum, item) => sum + item.debit);

  double get _netBalance => _totalCredit - _totalDebit;

  Future<void> _selectDate(BuildContext context, bool isStart) async {
    final picked = await showDatePicker(
      context: context,
      initialDate:
          isStart ? (_startDate ?? DateTime.now()) : (_endDate ?? DateTime.now()),
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
        } else {
          _endDate = picked;
        }
      });
    }
  }

  void _calculateRange() {
    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('অনুগ্রহ করে শুরুর তারিখ ও শেষের তারিখ দুটিই নির্বাচন করুন!'),
        ),
      );
      return;
    }

    if (_startDate!.isAfter(_endDate!)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('শুরুর তারিখ শেষের তারিখের চেয়ে বড় হতে পারে না!'),
        ),
      );
      return;
    }

    setState(() {
      _isFilterActive = true;
    });
  }

  void _resetFilter() {
    setState(() {
      _startDate = null;
      _endDate = null;
      _isFilterActive = false;
    });
  }

  void _showAddEntryDialog() {
    DateTime entryDate = DateTime.now();
    final creditController = TextEditingController();
    final debitController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'নতুন দৈনিক হিসাব যোগ করুন',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_today, color: Colors.teal),
                title: Text('তারিখ: ${_dateFormat.format(entryDate)}'),
                trailing: const Text(
                  'তারিখ পরিবর্তন',
                  style: TextStyle(
                    color: Colors.teal,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: ctx,
                    initialDate: entryDate,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2035),
                  );

                  if (picked != null) {
                    setModalState(() => entryDate = picked);
                  }
                },
              ),
              TextField(
                controller: creditController,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'জমা / Credit (৳)',
                  prefixIcon:
                      Icon(Icons.arrow_downward, color: Colors.green),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: debitController,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'খরচ / Debit (৳)',
                  prefixIcon: Icon(Icons.arrow_upward, color: Colors.red),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton(
                  onPressed: () async {
                    final cr = double.tryParse(creditController.text) ?? 0.0;
                    final dr = double.tryParse(debitController.text) ?? 0.0;

                    if (cr <= 0 && dr <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('জমা অথবা খরচের একটি পরিমাণ দিন।'),
                        ),
                      );
                      return;
                    }

                    setState(() {
                      _entries.insert(
                        0,
                        LedgerEntry(
                          id: DateTime.now().microsecondsSinceEpoch.toString(),
                          date: entryDate,
                          credit: cr,
                          debit: dr,
                        ),
                      );
                    });

                    await _saveEntries();

                    if (ctx.mounted) {
                      Navigator.pop(ctx);
                    }
                  },
                  child: const Text(
                    'সংরক্ষণ করুন',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _deleteEntry(LedgerEntry item) async {
    setState(() {
      _entries.removeWhere((e) => e.id == item.id);
    });

    await _saveEntries();
  }

  Future<void> _clearAllEntries() async {
    if (_entries.isEmpty) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('সব হিসাব মুছে ফেলবেন?'),
        content: const Text(
          'এই কাজটি করলে ফোনে সংরক্ষিত সব হিসাব স্থায়ীভাবে মুছে যাবে।',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('বাতিল'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('সব মুছুন'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() {
        _entries.clear();
        _startDate = null;
        _endDate = null;
        _isFilterActive = false;
      });

      await _saveEntries();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('দৈনিক হিসাব খাতা'),
        centerTitle: true,
        actions: [
          if (!_isLoading && _entries.isNotEmpty)
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'clear') {
                  _clearAllEntries();
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(
                  value: 'clear',
                  child: Text('সব হিসাব মুছুন'),
                ),
              ],
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                children: [
                  Card(
                    margin: const EdgeInsets.all(12),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.date_range,
                                  color: Colors.teal, size: 20),
                              SizedBox(width: 8),
                              Text(
                                'নির্দিষ্ট তারিখের হিসাব বের করুন',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: InkWell(
                                  onTap: () => _selectDate(context, true),
                                  borderRadius: BorderRadius.circular(8),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 12,
                                    ),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.grey.shade400),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'শুরুর তারিখ',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          _startDate != null
                                              ? _dateFormat.format(_startDate!)
                                              : 'সিলেক্ট করুন',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            color: _startDate != null
                                                ? Colors.black87
                                                : Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: InkWell(
                                  onTap: () => _selectDate(context, false),
                                  borderRadius: BorderRadius.circular(8),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 12,
                                    ),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.grey.shade400),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'শেষের তারিখ',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          _endDate != null
                                              ? _dateFormat.format(_endDate!)
                                              : 'সিলেক্ট করুন',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            color: _endDate != null
                                                ? Colors.black87
                                                : Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: FilledButton.icon(
                                  onPressed: _calculateRange,
                                  icon: const Icon(Icons.search, size: 18),
                                  label: const Text('হিসাব দেখুন'),
                                ),
                              ),
                              if (_isFilterActive) ...[
                                const SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: _resetFilter,
                                  child: const Text('রিসেট'),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        _buildSummaryBox(
                            'মোট জমা (Credit)', _totalCredit, Colors.green),
                        const SizedBox(width: 8),
                        _buildSummaryBox(
                            'মোট খরচ (Debit)', _totalDebit, Colors.red),
                        const SizedBox(width: 8),
                        _buildSummaryBox(
                            'অবশিষ্ট ব্যালেন্স', _netBalance, Colors.blue),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _isFilterActive
                              ? 'নির্দিষ্ট রেঞ্জের তালিকা (${_filteredEntries.length}টি)'
                              : 'সকল হিসাবের তালিকা (${_entries.length}টি)',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(),
                  _filteredEntries.isEmpty
                      ? const Padding(
                          padding: EdgeInsets.all(32.0),
                          child: Text(
                            'এই তারিখের মধ্যে কোনো হিসাব পাওয়া যায়নি।',
                            style: TextStyle(color: Colors.grey),
                          ),
                        )
                      : ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _filteredEntries.length,
                          separatorBuilder: (_, __) =>
                              const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final item = _filteredEntries[index];

                            return ListTile(
                              leading: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  _dateFormat.format(item.date),
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                              title: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  if (item.credit > 0)
                                    Text(
                                      '+ ৳${item.credit.toStringAsFixed(2)}',
                                      style: const TextStyle(
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  if (item.credit > 0 && item.debit > 0)
                                    const SizedBox(width: 12),
                                  if (item.debit > 0)
                                    Text(
                                      '- ৳${item.debit.toStringAsFixed(2)}',
                                      style: const TextStyle(
                                        color: Colors.red,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                ],
                              ),
                              trailing: IconButton(
                                icon: const Icon(
                                  Icons.delete_outline,
                                  size: 20,
                                  color: Colors.grey,
                                ),
                                onPressed: () => _deleteEntry(item),
                              ),
                            );
                          },
                        ),
                  const SizedBox(height: 80),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddEntryDialog,
        icon: const Icon(Icons.add),
        label: const Text('হিসাব যোগ করুন'),
      ),
    );
  }

  Widget _buildSummaryBox(
      String title, double amount, MaterialColor color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
        decoration: BoxDecoration(
          color: color.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.shade200),
        ),
        child: Column(
          children: [
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: color.shade800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '৳${amount.toStringAsFixed(0)}',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: color.shade900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
