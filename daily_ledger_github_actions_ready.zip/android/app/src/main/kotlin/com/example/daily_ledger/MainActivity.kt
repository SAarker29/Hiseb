package com.example.daily_ledger

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
